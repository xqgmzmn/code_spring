package com.chenxx;

import com.chenxx.dao.X;
import com.chenxx1.imports.ImportDao1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class app {
	public static void main(String[] args) {

		System.out.println("HELLO");
		ApplicationContext context = new AnnotationConfigApplicationContext(Appconfig.class);
		context.getBean(X.class);

//		X x = (X) context.getBean("x");
//		x.sayHi();
//
//
//		System.out.println("HELLO2");
//
//		System.out.println(context.containsBean("Appconfig.class"));
//		System.out.println("HELLO3");

	}


}



