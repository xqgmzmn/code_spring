package com.chenxx.dao;

import org.springframework.stereotype.Component;


@Component
public class Z extends Y{
	public void hello(){
		System.out.println("my name is Z");
	}

}
