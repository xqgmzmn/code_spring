package com.chenxx1.imports;

public class ImportDao1 {

	public void  query(){
		System.out.println("ImportDao1");
	}
}
