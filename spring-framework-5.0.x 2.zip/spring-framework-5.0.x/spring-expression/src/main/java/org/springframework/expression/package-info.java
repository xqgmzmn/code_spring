/**
 * Core abstractions behind the <em>Spring Expression Language</em>.
 */
@NonNullApi
@NonNullFields
package org.springframework.expression;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
